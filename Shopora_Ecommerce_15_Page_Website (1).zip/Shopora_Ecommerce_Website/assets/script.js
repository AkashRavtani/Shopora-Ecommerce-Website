const toggle = document.querySelector('.menu-toggle');
const links = document.querySelector('.navlinks');
if (toggle && links) {
  toggle.addEventListener('click', () => {
    const isOpen = links.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(isOpen));
  });
}
document.querySelectorAll('[data-demo-form]').forEach(form => {
  form.addEventListener('submit', event => {
    event.preventDefault();
    const message = form.querySelector('[data-form-message]');
    if (message) message.textContent = 'Thanks! This is a front-end demo, so no information was sent to a server.';
  });
});
document.querySelectorAll('[data-qty]').forEach(group => {
  const input = group.querySelector('input');
  group.querySelectorAll('button').forEach(button => button.addEventListener('click', () => {
    const current = Number(input.value || 1);
    input.value = button.dataset.qty === 'plus' ? current + 1 : Math.max(1, current - 1);
  }));
});
